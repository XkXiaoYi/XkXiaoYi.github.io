<html><head>
<meta http-equiv="Content-Type" content="text/html" charset="gb2312">
<link rel="stylesheet" href="../style.css" type="text/css">
<title>�ѱ����</title>
</head>
<body>
<br>
<p class="title1">�ѱ���������</p>

<p align="left"><font color="#0000ff" size="6"></font></p>
<form name="thefram" action="/cgi-bin/thfy.pl" method="post">
  <table cellSpacing="0" width="84%" border="1">
    <tbody>
      <tr>
        <td width="33%">Target��</td>
        <td width="67%">
<select size="1" name="TARGET" > 
<option value="Am-241">Am-241</option><option value="Am-242m">Am-242m</option><option value="Am-243">Am-243</option><option value="Cf-249">Cf-249</option><option value="Cf-250">Cf-250</option><option value="Cf-251">Cf-251</option><option value="Cf-252">Cf-252</option><option value="Cm-242">Cm-242</option><option value="Cm-243">Cm-243</option><option value="Cm-244">Cm-244</option><option value="Cm-245">Cm-245</option><option value="Cm-246">Cm-246</option><option value="Cm-248">Cm-248</option><option value="Es-253">Es-253</option><option value="Es-254">Es-254</option><option value="Fm-254">Fm-254</option><option value="Fm-255">Fm-255</option><option value="Fm-256">Fm-256</option><option value="Np-237">Np-237</option><option value="Np-238">Np-238</option><option value="Pa-231">Pa-231</option><option value="Pu-238">Pu-238</option><option value="Pu-239">Pu-239</option><option value="Pu-240">Pu-240</option><option value="Pu-241">Pu-241</option><option value="Pu-242">Pu-242</option><option value="Th-227">Th-227</option><option value="Th-229">Th-229</option><option value="Th-232">Th-232</option><option value="U-232">U-232</option><option value="U-233">U-233</option><option value="U-234">U-234</option><option value="U-235">U-235</option><option value="U-236">U-236</option><option value="U-237">U-237</option><option value="U-238">U-238</option></select></td> 
      </tr>
      <tr>
        <td width="3%">Independ or Communitive 
        </td>
        <td width="73%"><select size="1" name="IC">
            <option value="I">I</option>
            <option value="C">C</option>
            <option value="A" SELECTED>ALL</option>
          </select></td>
      </tr>
      <tr>
              <td width="3%">Product Nuclear A:</td>
        <td width="73%"><input type="text" name="A" size="7"> (��Ϊ��)</td>
       </tr>
      <tr>
            <td width="22%">Product Nuclear Z: </td>
        <td width="44%"><input type="text" name="Z" size="7"></td>

      </tr>
      <tr>
        <td width="3%">Energy:</td>
        <td width="73%">
	<select size="1" name="EN2">
	    <option value="0" Selected>ALL</option>
            <option value="1">S-->Spontaneous Fission</option>
            <option value="2">T-->Thermal Energy</option>
            <option value="3">F-->Fission Spectrum</option>
            <option value="4">H-->Fast Neutron</option>
          </select>
          </td>
      </tr>
     
    </tbody>
  </table>
    <p align="left"><input type="submit" value="�ύ" name="B1"><input type="reset" value="ȫ����д" name="B2"></p>

  </form>
<hr>
